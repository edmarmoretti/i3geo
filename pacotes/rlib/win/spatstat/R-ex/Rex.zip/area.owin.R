### Name: area.owin
### Title: Area of a Window
### Aliases: area.owin
### Keywords: spatial math

### ** Examples

  w <- unit.square()
  area.owin(w)
       # returns 1.00000

  k <- 6
  theta <- 2 * pi * (0:(k-1))/k
  co <- cos(theta)
  si <- sin(theta)
  mas <- owin(c(-1,1), c(-1,1), poly=list(x=co, y=si))
  area.owin(mas)
      # returns approx area of k-gon
  
  mas <- as.mask(w, eps=0.01)
  X <- raster.x(mas)
  Y <- raster.y(mas)
  mas$m <- ((X - 0.5)^2 + (Y - 0.5)^2 <= 1)
  area.owin(mas)
       # returns 3.14 approx     




