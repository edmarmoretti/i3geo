### Name: residuals.ppm
### Title: Residuals for Fitted Point Process Model
### Aliases: residuals.ppm
### Keywords: spatial models methods

### ** Examples

    data(cells)
    fit <- ppm(cells, ~x, Strauss(r=0.15), rbord=0.15)

    rp <- residuals.ppm(fit, type="pe")
    sum(rp) # should be close to 0

    # extract quadrature points to which the residuals correspond
    quadpoints <- union.quad(quad.ppm(fit))

    # plot residuals as marks attached to the quadrature points 
    quadmarked <- setmarks(quadpoints, rp)
    plot(quadmarked)



