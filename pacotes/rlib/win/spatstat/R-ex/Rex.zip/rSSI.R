### Name: rSSI
### Title: Simulate Simple Sequential Inhibition
### Aliases: rSSI
### Keywords: spatial datagen

### ** Examples

 pp <- rSSI(0.05, 200)
 ## Not run: plot(pp)



