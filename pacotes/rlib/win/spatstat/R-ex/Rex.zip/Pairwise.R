### Name: Pairwise
### Title: Generic Pairwise Interaction model
### Aliases: Pairwise
### Keywords: spatial models

### ** Examples

   #This is the same as StraussHard(r=0.7,h=0.2)
   strpot <- function(d,par) {
         r <- par$r
         h <- par$h
         value <- (d <= r)
         value[d < h] <- -Inf
         value
   }
   mySH <- Pairwise(strpot, "StraussHard", list(r=0.7,h=0.2),
           c("interaction distance r", "hard core distance c"))
   data(cells)
   ppm(cells, ~ 1, mySH)



