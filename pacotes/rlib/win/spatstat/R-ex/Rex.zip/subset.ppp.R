### Name: subset.ppp
### Title: Extract or Replace Subset of Point Pattern
### Aliases: subset.ppp [.ppp [<-.ppp
### Keywords: spatial manip

### ** Examples

 data(longleaf)
 # Longleaf pines data
 ## Not run: 
##D  plot(longleaf)
##D  
## End(Not run)
 ## Don't show:
        longleaf <- longleaf[seq(1,longleaf$n,by=10)]
 
## End Don't show
 # adult trees defined to have diameter at least 30 cm
 adult <- (longleaf$marks >= 30)
 longadult <- longleaf[adult]
 ## Not run: 
##D  plot(longadult)
##D  
## End(Not run)
 # note that the marks are still retained.
 # Use unmark(longadult) to remove the marks
 
 # New Zealand trees data
 data(nztrees)
 ## Not run: 
##D  plot(nztrees)          # plot shows a line of trees at the far right
##D  abline(v=148, lty=2)   # cut along this line
##D  
## End(Not run)
 nzw <- owin(c(0,148),c(0,95)) # the subwindow
 # trim dataset to this subwindow
 nzsub <- nztrees[nzw]
 ## Not run: 
##D  plot(nzsub)
##D  
## End(Not run)

 # Redwood data
 data(redwood) 
 ## Not run: 
##D  plot(redwood)
##D  
## End(Not run)
 # Random thinning: delete 60% of data
 retain <- (runif(redwood$n) < 0.4)
 thinred <- redwood[retain]
 ## Not run: 
##D  plot(thinred)
##D  
## End(Not run)
 # Scramble 60% of data
 modif <- (runif(redwood$n) < 0.6)
 scramble <- function(x) { runifpoint(x$n, x$window) }
 redwood[modif] <- scramble(redwood[modif])

 # Lansing woods data - multitype points
 data(lansing)
 ## Don't show:
    lansing <- lansing[seq(1, lansing$n, length=100)]
 
## End Don't show

 # Hickory trees
  hicks <- split(lansing)$hickory

 # Trees in subwindow
  win <- owin(c(0.3, 0.6),c(0.2, 0.5))
  lsub <- lansing[win]

 # Scramble the locations of trees in subwindow, retaining their marks
  lansing[win] <- scramble(lsub) %mark% (lsub$marks)
  



