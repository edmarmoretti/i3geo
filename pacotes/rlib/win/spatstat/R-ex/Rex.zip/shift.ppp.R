### Name: shift.ppp
### Title: Apply Vector Translation To Point Pattern
### Aliases: shift.ppp
### Keywords: spatial manip

### ** Examples

  data(cells)
  X <- shift(cells, c(2,3))
  ## Not run: 
##D   plot(X)
##D   # no discernible difference except coordinates are different
##D   
## End(Not run)
  Y <- superimpose(cells, shift(cells, c(0.1,0.1)))
  ## Not run: plot(Y)



