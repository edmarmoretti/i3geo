### Name: plot.ppm
### Title: plot a Fitted Point Process Model
### Aliases: plot.ppm
### Keywords: spatial hplot models

### ** Examples

 ## Not run: 
##D  data(cells)
##D  m <- ppm(cells, ~1, Strauss(0.05))
##D  pm <- plot(m) # The object ``pm'' will be plotted as well as saved
##D                # for future plotting.
##D  
## End(Not run)



