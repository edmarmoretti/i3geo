### Name: lurking
### Title: Lurking variable plot
### Aliases: lurking
### Keywords: spatial models hplot

### ** Examples

  data(nztrees)
  fit <- ppm(nztrees, ~x, Poisson())
  lurking(fit, expression(x))
  lurking(fit, expression(x), cumulative=FALSE)



