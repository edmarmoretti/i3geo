### Name: plot.listof
### Title: Plot a List of Things
### Aliases: plot.listof
### Keywords: spatial hplot

### ** Examples

# Multitype point pattern
 data(amacrine)
 plot(density(split(amacrine)))



