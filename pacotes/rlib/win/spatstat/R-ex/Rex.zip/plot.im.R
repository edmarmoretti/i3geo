### Name: plot.im
### Title: Plot a Pixel Image
### Aliases: plot.im image.im
### Keywords: spatial hplot

### ** Examples

   # an image
   Z <- setcov(owin())
   plot(Z)
   plot(Z, col=terrain.colors(128), axes=FALSE)



