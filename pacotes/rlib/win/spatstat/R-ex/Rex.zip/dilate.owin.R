### Name: dilate.owin
### Title: Dilate a Window
### Aliases: dilate.owin
### Keywords: spatial math

### ** Examples

  w <- owin(c(0,1),c(0,1))
  v <- dilate.owin(w, 0.1) 
  # returns rectangle [-0.1, 1.1] x [-0.1, 1.1]



