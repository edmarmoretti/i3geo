### Name: vcov.ppm
### Title: Variance-Covariance Matrix for a Fitted Point Process Model
### Aliases: vcov.ppm
### Keywords: spatial methods models

### ** Examples

  X <- rpoispp(42)
  fit <- ppm(X, ~ x + y)
  vcov(fit)
  vcov(fit, what="Fish")



