### Name: ppm
### Title: Fit Point Process Model to Data
### Aliases: ppm
### Keywords: spatial models

### ** Examples

 data(nztrees)
 ppm(nztrees)
 # fit the stationary Poisson process
 # to point pattern 'nztrees'

 Q <- quadscheme(nztrees) 
 ppm(Q) 
 # equivalent.

 ppm(nztrees, ~ x)
 # fit the nonstationary Poisson process 
 # with intensity function lambda(x,y) = exp(a + bx)
 # where x,y are the Cartesian coordinates
 # and a,b are parameters to be estimated

 ppm(nztrees, ~ polynom(x,2))
 # fit the nonstationary Poisson process 
 # with intensity function lambda(x,y) = exp(a + bx + cx^2)

 library(splines)
 ppm(nztrees, ~ bs(x,df=3))
 #       WARNING: do not use predict.ppm() on this result
 # Fits the nonstationary Poisson process 
 # with intensity function lambda(x,y) = exp(B(x))
 # where B is a B-spline with df = 3
 
 ppm(nztrees, ~1, Strauss(r=10), rbord=10)
 # Fit the stationary Strauss process with interaction range r=10
 # using the border method with margin rbord=10
  
 ppm(nztrees, ~ x, Strauss(13), correction="periodic")
 # Fit the nonstationary Strauss process with interaction range r=13
 # and exp(first order potential) =  activity = beta(x,y) = exp(a+bx)
 # using the periodic correction.

# Huang-Ogata fit:
## Not run: ppm(nztrees, ~1, Strauss(r=10), rbord=10, method="ho")
## Don't show:
ppm(nztrees, ~1, Strauss(r=10), rbord=10, method="ho", nsim=10)
## End Don't show

 # COVARIATES
 #
 X <- rpoispp(42)
 weirdfunction <- function(x,y){ 10 * x^2 + runif(length(x))}
 Zimage <- as.im(weirdfunction, unit.square())
 #
 # (a) covariate values in pixel image
 ppm(X, ~ y + Z, covariates=list(Z=Zimage))
 #
 # (b) covariate values in data frame
 Q <- quadscheme(X)
 xQ <- x.quad(Q)
 yQ <- y.quad(Q)
 Zvalues <- weirdfunction(xQ,yQ)
 ppm(Q, ~ y + Z, covariates=data.frame(Z=Zvalues))
 # Note Q not X

 ## MULTITYPE POINT PROCESSES ### 
 data(lansing)
 # Multitype point pattern --- trees marked by species
## Don't show:
 # equivalent functionality - smaller dataset
 data(betacells)
 
## End Don't show

 # fit stationary marked Poisson process
 # with different intensity for each species
## Not run: ppm(lansing, ~ marks, Poisson())
## Don't show:
ppm(betacells, ~ marks, Poisson())
## End Don't show

 # fit nonstationary marked Poisson process
 # with different log-cubic trend for each species
## Not run: ppm(lansing, ~ marks * polynom(x,y,3), Poisson())
## Don't show:
ppm(betacells, ~ marks * polynom(x,y,2), Poisson())
## End Don't show




