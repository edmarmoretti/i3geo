### Name: Jdot
### Title: Multitype J Function (i-to-any)
### Aliases: Jdot
### Keywords: spatial nonparametric

### ** Examples

     # Lansing woods data: 6 types of trees
    data(lansing)

    ## Don't show:
        lansing <- lansing[seq(1,lansing$n, by=30), ]
    
## End Don't show
    Jh. <- Jdot(lansing, "hickory")
    plot(Jh.)
    # diagnostic plot for independence between hickories and other trees
    Jhh <- Jest(lansing[lansing$marks == "hickory", ])
    plot(Jhh, add=TRUE)

    # synthetic example with two marks "a" and "b"
    pp <- runifpoispp(50)
    pp <- pp %mark% sample(c("a","b"), pp$n, replace=TRUE)
    J <- Jdot(pp, "a")



