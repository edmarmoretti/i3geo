### Name: profilepl
### Title: Profile Maximum Pseudolikelihood
### Aliases: profilepl
### Keywords: spatial models

### ** Examples

    data(cells)

    # one irregular parameter
    s <- data.frame(r=seq(0.05,0.15, by=0.01))
    ## Don't show:
      s <- data.frame(r=c(0.05,0.1,0.15))
    
## End Don't show
    ps <- profilepl(s, Strauss, cells)
    ps
    plot(ps)

    # two irregular parameters
    s <- expand.grid(r=seq(0.05,0.15, by=0.01),sat=1:3)
    ## Don't show:
      s <- expand.grid(r=c(0.05,0.1,0.15),sat=1:2)
    
## End Don't show
    pg <- profilepl(s, Geyer, cells)
    pg
    plot(pg)
    ## Not run: 
##D     pg$fit
##D     
## End(Not run)



