### Name: plot.splitppp
### Title: Plot a List of Point Patterns
### Aliases: plot.splitppp
### Keywords: spatial hplot

### ** Examples

# Multitype point pattern
 data(amacrine)
 plot(split(amacrine))



