### Name: multiplicity.ppp
### Title: Count Multiplicity of Duplicate Points
### Aliases: multiplicity.ppp
### Keywords: spatial utilities

### ** Examples

   X <- ppp(c(1,1,0.5), c(2,2,1), window=square(3))
   m <- multiplicity.ppp(X)

   # unique points in X, marked by multiplicity
   first <- !duplicated(X)
   Y <- X[first] %mark% m[first]



