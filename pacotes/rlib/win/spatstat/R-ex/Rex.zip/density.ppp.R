### Name: density.ppp
### Title: Kernel Smoothed Intensity of Point Pattern
### Aliases: density.ppp
### Keywords: spatial methods smooth

### ** Examples

  data(cells)
  Z <- density.ppp(cells, 0.05)
  plot(Z)



