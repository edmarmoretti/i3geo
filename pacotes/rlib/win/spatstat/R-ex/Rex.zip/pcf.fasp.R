### Name: pcf.fasp
### Title: Pair Correlation Function obtained from array of K functions
### Aliases: pcf.fasp
### Keywords: spatial nonparametric

### ** Examples

  # multitype point pattern
  data(betacells)
  ## Don't show:
     betacells <- betacells[seq(1,betacells$n, by=10)]
  
## End Don't show
  KK <- alltypes(betacells, "K")
  p <- pcf.fasp(KK, spar=0.5, method="b")
  plot(p)
  # short range inhibition between all types
  # strong inhibition between "on" and "off"



