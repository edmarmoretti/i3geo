### Name: Kcross.inhom
### Title: Inhomogeneous Cross K Function
### Aliases: Kcross.inhom
### Keywords: spatial nonparametric

### ** Examples

    # Lansing Woods data
    data(lansing)
    lansing <- lansing[seq(1,lansing$n, by=10)]
    ma <- split(lansing)$maple
    wh <- split(lansing)$whiteoak

    # method (1): estimate intensities by nonparametric smoothing
    lambdaM <- density.ppp(ma, sigma=0.15)
    lambdaW <- density.ppp(wh, sigma=0.15)
    K <- Kcross.inhom(lansing, "whiteoak", "maple", lambdaW[wh], lambdaM[ma])
    K <- Kcross.inhom(lansing, "whiteoak", "maple", lambdaW,     lambdaM)

    # method (2): fit parametric intensity model
    fit <- ppm(lansing, ~marks * polynom(x,y,2))
    # evaluate fitted intensities at data points
    # (these are the intensities of the sub-processes of each type)
    inten <- fitted(fit, dataonly=TRUE)
    # split according to types of points
    lambda <- split(inten, lansing$marks)
    K <- Kcross.inhom(lansing, "whiteoak", "maple",
              lambda$whiteoak, lambda$maple)
    
    # synthetic example: type A points have intensity 50,
    #                    type B points have intensity 100 * x
    lamB <- as.im(function(x,y){50 + 100 * x}, owin())
    X <- superimpose(A=runifpoispp(50), B=rpoispp(lamB))
    XA <- split(X)$A
    XB <- split(X)$B
    K <- Kcross.inhom(X, "A", "B",
        lambdaI=rep(50, XA$n), lambdaJ=lamB[XB])
    K <- Kcross.inhom(X, "A", "B",
        lambdaI=as.im(50, X$window), lambdaJ=lamB)



