### Name: rmhstart
### Title: Determine Initial State for Metropolis-Hastings Simulation.
### Aliases: rmhstart rmhstart.default
### Keywords: spatial datagen

### ** Examples

   # 30 random points
   a <- rmhstart(n.start=30)

   # a particular point pattern
   data(cells)
   b <- rmhstart(x.start=cells)

   # set the seed
   d <- rmhstart(n.start=30, iseed=c(42, 4, 2))



