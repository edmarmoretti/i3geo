### Name: alltypes
### Title: Calculate Statistic for All Types in a Multitype Point Pattern
### Aliases: alltypes
### Keywords: spatial nonparametric

### ** Examples

   # bramblecanes (3 marks).
   data(bramblecanes)
   ## Not run: 
##D    X.F <- alltypes(bramblecanes,fun="F",verb=TRUE)
##D    plot(X.F) 
##D    X.G <- alltypes(bramblecanes,fun="G",verb=TRUE)
##D    X.J <- alltypes(bramblecanes,fun="J",verb=TRUE)
##D    X.K <- alltypes(bramblecanes,fun="K",verb=TRUE)
##D    X.Gd <- alltypes(bramblecanes,fun="Gdot",verb=TRUE)
##D    X.Jd <- alltypes(bramblecanes,fun="Jdot",verb=TRUE)
##D    X.Kd <- alltypes(bramblecanes,fun="Kdot",verb=TRUE)
##D    
## End(Not run)
   ## Don't show:
      # smaller dataset
      bram <- bramblecanes[seq(1, bramblecanes$n, by=20), ]
      X.F <- alltypes(bram,fun="F",verb=TRUE)
      X.G <- alltypes(bram,fun="G",verb=TRUE)
      X.J <- alltypes(bram,fun="J",verb=TRUE)
      X.K <- alltypes(bram,fun="K",verb=TRUE)
      X.Gd <- alltypes(bram,fun="Gdot",verb=TRUE)
      X.Jd <- alltypes(bram,fun="Jdot",verb=TRUE)
      X.Kd <- alltypes(bram,fun="Kdot",verb=TRUE)
   
## End Don't show
   
   # Swedishpines (unmarked).
   data(swedishpines)
   ## Don't show:
        swedishpines <- swedishpines[1:25]
   
## End Don't show
   X.K <- alltypes(swedishpines,fun="K")
   X.F <- alltypes(swedishpines,fun="F")
   X.G <- alltypes(swedishpines,fun="G")
   X.J <- alltypes(swedishpines,fun="J")

   # simulated data
   ## Not run: 
##D    pp <- runifpoint(350, owin(c(0,1),c(0,1)))
##D    pp$marks <- factor(c(rep(1,50),rep(2,100),rep(3,200)))
##D    X.F <- alltypes(pp,fun="F",verb=TRUE,dataname="Fake Data")
##D    X.G <- alltypes(pp,fun="G",verb=TRUE,dataname="Fake Data")
##D    X.J <- alltypes(pp,fun="J",verb=TRUE,dataname="Fake Data")
##D    X.K <- alltypes(pp,fun="K",verb=TRUE,dataname="Fake Data")
##D    
## End(Not run)

   # A setting where you might REALLY want to use dataname:
   ## Not run: 
##D    xxx <- alltypes(ppp(Melvin$x,Melvin$y,
##D                 window=as.owin(c(5,20,15,50)),marks=clyde),
##D                 fun="F",verb=TRUE,dataname="Melvin")
##D    
## End(Not run)



