### Name: finpines
### Title: Pine saplings in Finland.
### Aliases: finpines finpines.extra
### Keywords: datasets spatial

### ** Examples

    data(finpines)
    plot(unmark(finpines), main="Finnish pines: locations")
    plot(finpines, main="locations and heights")
    plot(finpines %mark% finpines.extra$diameter, main="diameters")



