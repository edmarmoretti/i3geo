### Name: rMatClust
### Title: Simulate Matern Cluster Process
### Aliases: rMatClust
### Keywords: spatial datagen

### ** Examples

 pp <- rMatClust(10, 0.05, 4)



