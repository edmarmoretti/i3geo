### Name: cut.ppp
### Title: Convert Point Pattern Marks from Numeric to Factor
### Aliases: cut.ppp
### Keywords: spatial methods

### ** Examples

 data(longleaf)
 # Longleaf Pines data
 # the marks are positive real numbers indicating tree diameters.

 ## Don't show:
        # smaller dataset
        longleaf <- longleaf[seq(1, longleaf$n, by=80)]
 
## End Don't show
 ## Not run: 
##D  plot(longleaf)
##D  
## End(Not run)

 # cut the range of tree diameters into three intervals
 long3 <- cut(longleaf, 3)
 ## Not run: 
##D  plot(long3)
##D  
## End(Not run)

 # adult trees defined to have diameter at least 30 cm
 long2 <- cut(longleaf, breaks=c(0,30,100), labels=c("Sapling", "Adult"))
 plot(long2)
 plot(long2, cols=c("green","blue"))



