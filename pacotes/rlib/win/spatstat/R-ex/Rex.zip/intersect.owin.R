### Name: intersect.owin
### Title: Intersection or Union of Two Windows
### Aliases: intersect.owin union.owin
### Keywords: spatial math

### ** Examples

# rectangles
   u <- unit.square()
   v <- owin(c(0.5,3.5), c(0.4,2.5))
# polygon
   data(letterR)
# mask
   m <- as.mask(letterR)

# two rectangles
   intersect.owin(u, v) 
   union.owin(u,v)

# polygon and rectangle
   intersect.owin(letterR, v)
   union.owin(letterR,v)

# mask and rectangle
   intersect.owin(m, v)
   union.owin(m,v)
#
   A <- letterR
   B <- rotate(letterR, 0.2)
   plot(bounding.box(A,B), main="intersection")
   w <- intersect.owin(A, B)
   plot(w, add=TRUE)
   plot(A, add=TRUE)
   plot(B, add=TRUE)

   plot(bounding.box(A,B), main="union")
   w <- union.owin(A,B)
   plot(w, add=TRUE)   
   plot(A, add=TRUE)
   plot(B, add=TRUE)



