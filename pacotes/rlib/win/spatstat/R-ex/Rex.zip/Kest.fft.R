### Name: Kest.fft
### Title: K-function using FFT
### Aliases: Kest.fft
### Keywords: spatial nonparametric

### ** Examples

 pp <- runifpoint(10000)
 ## Not run: 
##D  spatstat.options(npixel=512)
##D  
## End(Not run)
 ## Don't show:
  spatstat.options(npixel=256)
 
## End Don't show
 Kpp <- Kest.fft(pp, 0.01)
 plot(Kpp)



