### Name: applynbd
### Title: Apply Function to Every Neighbourhood in a Point Pattern
### Aliases: applynbd
### Keywords: spatial programming iteration

### ** Examples

  data(redwood)

  # count the number of points within radius 0.2 of each point of X
  nneighbours <- applynbd(redwood, R=0.2, function(Y, ...){Y$n-1})
  # equivalent to:
  nneighbours <- applynbd(redwood, R=0.2, function(Y, ...){Y$n}, exclude=TRUE)

  # compute the distance to the second nearest neighbour of each point
  secondnndist <- applynbd(redwood, N = 2,
                           function(dists, ...){max(dists)},
                           exclude=TRUE)

  # marked point pattern
  data(longleaf)
  ## Don't show:
        # smaller dataset
        longleaf <- longleaf[seq(1, longleaf$n, by=80)]
  
## End Don't show
  # compute the median of the marks of all neighbours of a point
  # (see also 'markstat')
  dbh.med <- applynbd(longleaf, R=90, exclude=TRUE,
                 function(Y, ...) { median(Y$marks)})

  # ANIMATION explaining the definition of the K function
  # (arguments `fullpicture' and 'rad' are passed to FUN)

  ## Not run: 
##D   showoffK <- function(Y, current, dists, dranks, fullpicture,rad) { 
##D         plot(fullpicture, main="")
##D         points(Y, cex=2)
##D         u <- current
##D         points(u[1],u[2],pch="+",cex=3)
##D         theta <- seq(0,2*pi,length=100)
##D         polygon(u[1]+ rad * cos(theta),u[2]+rad*sin(theta))
##D         text(u[1]+rad/3,u[2]+rad/2,Y$n,cex=3)
##D         Sys.sleep(if(runif(1) < 0.1) 1.5 else 0.3)
##D         return(Y$n - 1)
##D   }
##D   applynbd(redwood, R=0.2, showoffK, fullpicture=redwood, rad=0.2, exclude=TRUE)
##D 
##D   # animation explaining the definition of the G function
##D 
##D   showoffG <- function(Y, current, dists, dranks, fullpicture) { 
##D         plot(fullpicture, main="")
##D         points(Y, cex=2)
##D         u <- current
##D         points(u[1],u[2],pch="+",cex=3)
##D         v <- c(Y$x[1],Y$y[1])
##D         segments(u[1],u[2],v[1],v[2],lwd=2)
##D         w <- (u + v)/2
##D         nnd <- dists[1]
##D         text(w[1],w[2],round(nnd,3),cex=2)
##D         Sys.sleep(if(runif(1) < 0.1) 1.5 else 0.3)
##D         return(nnd)
##D   }
##D 
##D   data(cells)
##D   applynbd(cells, N=1, showoffG, exclude=TRUE, fullpicture=cells)
##D   
## End(Not run)



