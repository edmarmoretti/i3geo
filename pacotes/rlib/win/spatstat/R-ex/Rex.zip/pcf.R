### Name: pcf
### Title: Pair Correlation Function
### Aliases: pcf
### Keywords: spatial nonparametric

### ** Examples

  # ppp object
  data(simdat)
  ## Don't show:
    simdat <- simdat[seq(1,simdat$n, by=4)]
  
## End Don't show
  p <- pcf(simdat)
  plot(p)

  # fv object
  K <- Kest(simdat)
  p2 <- pcf(K)
  plot(p2)

  # multitype pattern; fasp object
  data(betacells)
  ## Don't show:
     betacells <- betacells[seq(1,betacells$n, by=10)]
  
## End Don't show
  p <- pcf(alltypes(betacells, "K"))
  plot(p)



