### Name: rmh
### Title: Simulate point patterns using the Metropolis-Hastings algorithm.
### Aliases: rmh
### Keywords: spatial datagen

### ** Examples

    # See examples in rmh.default and rmh.ppm



