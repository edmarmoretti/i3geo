### Name: rotate.owin
### Title: Rotate a Window
### Aliases: rotate.owin
### Keywords: spatial math

### ** Examples

  w <- owin(c(0,1),c(0,1))
  v <- rotate(w, pi/3)
  ## Not run: 
##D   plot(v)
##D   
## End(Not run)



