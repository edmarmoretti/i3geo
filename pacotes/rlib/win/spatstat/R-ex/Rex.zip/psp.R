### Name: psp
### Title: Create a Line Segment Pattern
### Aliases: psp
### Keywords: spatial datagen

### ** Examples

  X <- psp(runif(20), runif(20), runif(20), runif(20),  window=owin())



