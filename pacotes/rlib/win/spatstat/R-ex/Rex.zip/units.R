### Name: units
### Title: Name for Unit of Length
### Aliases: units units.owin units.psp units.ppp units.im units<-
###   units<-.ppp units<-.psp units<-.owin units<-.im
### Keywords: spatial manip

### ** Examples

  X <- runifpoint(20)

  # if the unit of length is 1 metre:
  units(X) <- c("metre", "metres")

  # if the unit of length is 6 inches:
  units(X) <- list("inch", "inches", 6)



