### Name: persp.im
### Title: Perspective Plot of Pixel Image
### Aliases: persp.im
### Keywords: spatial hplot

### ** Examples

   # an image
   Z <- setcov(owin())
   persp(Z, colmap=terrain.colors(128), axes=FALSE, shade=0.3)



