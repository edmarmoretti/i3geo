### Name: subset.fasp
### Title: Extract Subset of Function Array
### Aliases: subset.fasp [.fasp
### Keywords: spatial manip

### ** Examples

 # Lansing woods data - multitype points with 6 types
 data(lansing)
 ## Don't show:
 # smaller dataset
   lansing <- lansing[ seq(1,lansing$n,by=45), ]
 
## End Don't show
 # compute 6 x 6 array of all cross-type K functions
 a <- alltypes(lansing, "K")

 # extract first three marks only
 b <- a[1:3,1:3]
 ## Not run: plot(b)
 # subset pertaining to hickories
 h <- a[levels(lansing$marks) == "hickory", ]
 ## Not run: plot(h)



