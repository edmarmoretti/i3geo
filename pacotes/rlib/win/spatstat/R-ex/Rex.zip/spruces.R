### Name: spruces
### Title: Spruces Point Pattern
### Aliases: spruces
### Keywords: datasets spatial

### ** Examples

     data(spruces)
     plot(spruces)
     # To reproduce Goulard et al. Figure 3
     plot(spruces, maxsize=5*max(spruces$marks))
     plot(unmark(spruces), add=TRUE)



