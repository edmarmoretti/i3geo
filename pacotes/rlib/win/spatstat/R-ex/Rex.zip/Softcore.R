### Name: Softcore
### Title: The Soft Core Point Process Model
### Aliases: Softcore
### Keywords: spatial models

### ** Examples

   data(cells) 
   ppm(cells, ~1, Softcore(kappa=0.5), rbord=0)
   # fit the stationary Soft Core process to `cells'



