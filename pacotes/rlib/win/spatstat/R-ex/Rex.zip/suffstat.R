### Name: suffstat
### Title: Sufficient Statistic of Point Process Model
### Aliases: suffstat
### Keywords: spatial models

### ** Examples

    data(swedishpines)
    fitS <- ppm(swedishpines, ~1, Strauss(7))
    X <- rpoispp(summary(swedishpines)$intensity, win=swedishpines$window)
    suffstat(fitS, X)



