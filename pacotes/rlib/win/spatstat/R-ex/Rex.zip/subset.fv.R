### Name: subset.fv
### Title: Extract Subset of Function Values
### Aliases: subset.fv [.fv
### Keywords: spatial manip

### ** Examples

 data(cells)
 K <- Kest(cells)

 # discard the estimates of K(r) for r  > 0.1
 Ksub <- K[K$r <= 0.1, ]

 # discard the border method estimator
 Ksub <- K[ , names(K) != "border"]
 



