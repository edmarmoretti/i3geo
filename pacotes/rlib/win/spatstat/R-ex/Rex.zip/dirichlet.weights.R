### Name: dirichlet.weights
### Title: Compute Quadrature Weights Based on Dirichlet Tessellation
### Aliases: dirichlet.weights
### Keywords: spatial utilities

### ** Examples

  Q <- quadscheme(runifpoispp(10))
  X <- as.ppp(Q) # data and dummy points together
  w <- dirichlet.weights(X, exact=FALSE)



