### Name: is.multitype.ppm
### Title: Test Whether A Point Process Model is Multitype
### Aliases: is.multitype.ppm
### Keywords: spatial manip models

### ** Examples

   data(lansing)
   # Multitype point pattern --- trees marked by species

   ## Don't show:
      # Smaller dataset
      data(betacells)
      lansing <- betacells[seq(2, 135, by=3), ]
   
## End Don't show

  fit1 <- ppm(lansing, ~ marks, Poisson())
  is.multitype(fit1)
  # TRUE

  fit2 <- ppm(lansing, ~ 1, Poisson())
  is.multitype(fit2)
  # TRUE

  data(cells)
  # Unmarked point pattern

  fit3 <- ppm(cells, ~ 1, Poisson())
  is.multitype(fit3)
  # FALSE




