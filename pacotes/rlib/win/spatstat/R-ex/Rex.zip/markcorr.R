### Name: markcorr
### Title: Mark Correlation Function
### Aliases: markcorr
### Keywords: spatial nonparametric

### ** Examples

    # CONTINUOUS-VALUED MARKS:
    # (1) Longleaf Pine data
    # marks represent tree diameter
    data(longleaf)
    # Subset of this large pattern
    swcorner <- owin(c(0,100),c(0,100))
    sub <- longleaf[ , swcorner]
    # mark correlation function
    mc <- markcorr(sub)
    plot(mc)

    # (2) simulated data with independent marks
    X <- rpoispp(100)
    X <- X %mark% runif(X$n)
    Xc <- markcorr(X)
    plot(Xc)
    
    # MULTITYPE DATA:
    # Hughes' amacrine data
    # Cells marked as 'on'/'off'
    data(amacrine)
    # (3) Kernel density estimate with Epanecnikov kernel
    # (as proposed by Stoyan & Stoyan)
    M <- markcorr(amacrine, function(m1,m2) {m1==m2},
                  correction="translate", method="density",
                  kernel="epanechnikov")
    plot(M)
    # Note: kernel="epanechnikov" comes from help(density)

    # (4) Same again with explicit control over bandwidth
    M <- markcorr(amacrine, 
                  correction="translate", method="density",
                  kernel="epanechnikov", bw=0.02)
    # see help(density) for correct interpretation of 'bw'

   ## Don't show:
    data(betacells)
    betacells <- betacells[seq(1,betacells$n,by=3)]
    niets <- markcorr(betacells, function(m1,m2){m1 == m2}, method="loess")
    niets <- markcorr(X, correction="isotropic", method="smrep", hmult=2)
    
## End Don't show



