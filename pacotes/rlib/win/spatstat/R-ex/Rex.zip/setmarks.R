### Name: setmarks
### Title: Set or Reset the Marks in a Point Pattern
### Aliases: setmarks \%mark\%
### Keywords: spatial manip

### ** Examples

   data(cells)

   m <- runif(cells$n)

   Y <- setmarks(cells, m)
   Y <- cells %mark% m
   # equivalent

   ## Not run: plot(Y)
   is.marked(Y)  #TRUE



