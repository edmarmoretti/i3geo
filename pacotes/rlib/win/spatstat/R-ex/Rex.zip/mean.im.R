### Name: mean.im
### Title: Mean Pixel Value in an Image
### Aliases: mean.im
### Keywords: spatial methods univar

### ** Examples

  X <- as.im(function(x,y) {x^2}, unit.square())
  mean(X)
  mean(X, trim=0.05)



