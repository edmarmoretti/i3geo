### Name: Gmulti
### Title: Marked Nearest Neighbour Distance Function
### Aliases: Gmulti
### Keywords: spatial nonparametric

### ** Examples

    data(longleaf)
     # Longleaf Pine data: marks represent diameter
    ## Don't show:
      longleaf <- longleaf[seq(1,longleaf$n, by=50), ]
    
## End Don't show
    Gm <- Gmulti(longleaf, longleaf$marks <= 15, longleaf$marks >= 25)
    plot(Gm)



