### Name: spokes
### Title: Spokes pattern of dummy points
### Aliases: spokes
### Keywords: spatial datagen

### ** Examples

  dat <- runifrect(10)
  ## Not run: 
##D   plot(dat)
##D   
## End(Not run)
  dum <- spokes(dat$x, dat$y)
  ## Not run: 
##D   points(dum$x, dum$y, pch=".")
##D   
## End(Not run)
  Q <- quadscheme(dat, dum)



