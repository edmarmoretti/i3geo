### Name: summary.ppp
### Title: Summary of a Point Pattern Dataset
### Aliases: summary.ppp
### Keywords: spatial methods

### ** Examples

  data(cells)      # plain vanilla point pattern
  summary(cells)  

  data(lansing)    # multitype point pattern
  ## Don't show:
lansing <- lansing[seq(1, lansing$n, length=40)]
## End Don't show
  summary(lansing) # tabulates frequencies of each mark
  
  data(longleaf)    # numeric marks
  ## Don't show:
longleaf <- longleaf[seq(1, longleaf$n, length=40)]
## End Don't show
  summary(longleaf) # prints summary.default(x$marks)

  data(demopat)     # weird polygonal window
  summary(demopat)  # describes it



