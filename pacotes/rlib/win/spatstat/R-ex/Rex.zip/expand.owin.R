### Name: expand.owin
### Title: Expand Window By Factor
### Aliases: expand.owin
### Keywords: spatial manip

### ** Examples

  w <- square(1)
  expand.owin(w, 9)
  # returns the square [-1,2] x [-1,2]



