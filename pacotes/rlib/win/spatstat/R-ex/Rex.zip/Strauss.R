### Name: Strauss
### Title: The Strauss Point Process Model
### Aliases: Strauss
### Keywords: spatial models

### ** Examples

   Strauss(r=0.1)
   # prints a sensible description of itself
   data(cells) 
   ppm(cells, ~1, Strauss(r=0.07), rbord=0.07)
   # fit the stationary Strauss process to `cells'
   ppm(cells, ~polynom(x,y,3), Strauss(r=0.07), rbord=0.1)
   # fit a nonstationary Strauss process with log-cubic polynomial trend



