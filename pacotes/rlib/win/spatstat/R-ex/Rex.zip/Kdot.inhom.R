### Name: Kdot.inhom
### Title: Inhomogeneous Multitype K Dot Function
### Aliases: Kdot.inhom
### Keywords: spatial nonparametric

### ** Examples

    # Lansing Woods data
    data(lansing)
    lansing <- lansing[seq(1,lansing$n, by=10)]
    ma <- split(lansing)$maple
    lg <- unmark(lansing)

    # Estimate intensities by nonparametric smoothing
    lambdaM <- density.ppp(ma, sigma=0.15)
    lambdadot <- density.ppp(lg, sigma=0.15)
    K <- Kdot.inhom(lansing, "maple", lambdaI=lambdaM[ma],
                                      lambdadot=lambdadot[lg])
    K <- Kdot.inhom(lansing, "maple", lambdaI=lambdaM,
                                      lambdadot=lambdadot)

    # synthetic example: type A points have intensity 50,
    #                    type B points have intensity 50 + 100 * x
    lamB <- as.im(function(x,y){50 + 100 * x}, owin())
    lamdot <- as.im(function(x,y) { 100 + 100 * x}, owin())
    X <- superimpose(A=runifpoispp(50), B=rpoispp(lamB))
    XB <- split(X)$B
    K <- Kdot.inhom(X, "B",  lambdaI=lamB[XB], lambdadot=lamdot[X])
    K <- Kdot.inhom(X, "B",  lambdaI=lamB,     lambdadot=lamdot)



