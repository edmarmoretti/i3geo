### Name: betacells
### Title: Beta Ganglion Cells in Cat Retina
### Aliases: betacells betacells.extra
### Keywords: datasets spatial

### ** Examples

   data(betacells)
   plot(betacells)
   plot(betacells$window, main="beta cells")
   symbols(betacells$x, betacells$y,
       circles=sqrt(betacells.extra$area/pi),
       inches=FALSE, add=TRUE)



