### Name: rThomas
### Title: Simulate Thomas Process
### Aliases: rThomas
### Keywords: spatial datagen

### ** Examples

  X <- rThomas(10, 0.2, 5)



