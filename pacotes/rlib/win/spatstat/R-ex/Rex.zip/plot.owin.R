### Name: plot.owin
### Title: Plot a Spatial Window
### Aliases: plot.owin
### Keywords: spatial hplot

### ** Examples

## Not run: 
##D   # rectangular window
##D    data(nztrees)
##D    plot(nztrees$window)
##D    abline(v=148, lty=2)
##D 
##D   # polygonal window
##D   plot(c(0,1),c(0,1),type="n")
##D   bdry <- locator()
##D   # click the vertices of a polygon (anticlockwise)
##D   w <- owin(c(0,1), c(0,1), poly=bdry)
##D   plot(w)
##D 
##D   # binary mask
##D   we <- erode.owin(w, 0.05, FALSE)
##D   plot(we)
##D   spatstat.options(par.binary=list(col=grey(c(0.5,1))))
##D   plot(we)
## End(Not run)



