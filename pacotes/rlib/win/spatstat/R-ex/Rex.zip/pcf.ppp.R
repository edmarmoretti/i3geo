### Name: pcf.ppp
### Title: Pair Correlation Function of Point Pattern
### Aliases: pcf.ppp
### Keywords: spatial nonparametric

### ** Examples

  data(simdat)
  p <- pcf(simdat)
  ## Don't show:
    simdat <- simdat[seq(1,simdat$n, by=4)]
  
## End Don't show
  plot(p, main="pair correlation function for simdat")
  # indicates inhibition at distances r < 0.3



