### Name: density.psp
### Title: Kernel Smoothing of Line Segment Pattern
### Aliases: density.psp
### Keywords: spatial methods smooth

### ** Examples

  L <- psp(runif(20),runif(20),runif(20),runif(20), window=owin())
  D <- density(L, sigma=0.03)
  plot(D, main="density(L)")
  plot(L, add=TRUE)



