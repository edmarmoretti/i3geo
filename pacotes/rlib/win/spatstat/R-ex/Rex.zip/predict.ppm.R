### Name: predict.ppm
### Title: Prediction from a Fitted Point Process Model
### Aliases: predict.ppm
### Keywords: spatial models

### ** Examples

  data(cells)
  m <- ppm(cells, ~ polynom(x,y,2), Strauss(0.05), rbord=0.05)
  trend <- predict(m, type="trend")
  ## Not run: 
##D   image(trend)
##D   points(cells)
##D   
## End(Not run)
  cif <- predict(m, type="cif")
  ## Not run: 
##D   persp(cif)
##D   
## End(Not run)



