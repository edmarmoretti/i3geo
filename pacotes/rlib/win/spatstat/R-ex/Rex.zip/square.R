### Name: square
### Title: Square Window
### Aliases: square unit.square
### Keywords: spatial datagen

### ** Examples

 W <- square(10)



