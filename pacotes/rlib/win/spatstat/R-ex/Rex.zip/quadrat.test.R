### Name: quadrat.test
### Title: Chi-Squared Dispersion Test for Spatial Point Pattern Based on
###   Quadrat Counts
### Aliases: quadrat.test
### Keywords: spatial htest

### ** Examples

  data(simdat)
  quadrat.test(simdat)
  quadrat.test(simdat, 4)

  # fitted model: inhomogeneous Poisson
  fitx <- ppm(simdat, ~x, Poisson())
  # equivalent:
  quadrat.test(simdat, fit=fitx)
  quadrat.test(fitx)

  te <- quadrat.test(simdat, 4)
  residuals(te)  # Pearson residuals

  plot(te)

  plot(simdat, pch="+", col="green", cex=1.2, lwd=2)
  plot(te, add=TRUE, col="red", cex=1.5, lty=2, lwd=3)

  sublab <- eval(substitute(expression(p[chi^2]==z),
                       list(z=signif(te$p.value,3))))
  title(sub=sublab, cex.sub=3)




