### Name: pcf.fv
### Title: Pair Correlation Function obtained from K Function
### Aliases: pcf.fv
### Keywords: spatial nonparametric

### ** Examples

  # univariate point pattern
  data(simdat)
  ## Don't show:
    simdat <- simdat[seq(1,simdat$n, by=4)]
  
## End Don't show
  K <- Kest(simdat)
  p <- pcf.fv(K, spar=0.5, method="b")
  plot(p, main="pair correlation function for simdat")
  # indicates inhibition at distances r < 0.3



