### Name: lgcp.estK
### Title: Fit a Log-Gaussian Cox Point Process by Minimum Contrast
### Aliases: lgcp.estK
### Keywords: spatial models

### ** Examples

    data(redwood)
    u <- lgcp.estK(redwood, c(sigma2=0.1, alpha=1))
    u
    plot(u)



