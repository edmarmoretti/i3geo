### Name: fasp.object
### Title: Function Arrays for Spatial Patterns
### Aliases: fasp.object
### Keywords: spatial attribute

### ** Examples

  # unmarked point pattern
  data(swedishpines)
  ## Don't show:
        # smaller dataset
        swedishpines <- swedishpines[1:30]
  
## End Don't show
  a <- allstats(swedishpines,dataname="Swedish Pines")
  a
  plot(a)
  plot(a[1,])

  # multitype point pattern
  data(amacrine)
  a <- alltypes(amacrine, "G")
  plot(a)

  # select the row corresponding to cells of type "on"
  b <- a["on", ]
  plot(b)



