### Name: Kmulti
### Title: Marked K-Function
### Aliases: Kmulti
### Keywords: spatial nonparametric

### ** Examples

    data(longleaf)
     # Longleaf Pine data: marks represent diameter
    ## Don't show:
        longleaf <- longleaf[seq(1,longleaf$n, by=50), ]
    
## End Don't show
    K <- Kmulti(longleaf, longleaf$marks <= 15, longleaf$marks >= 25)
    plot(K)



