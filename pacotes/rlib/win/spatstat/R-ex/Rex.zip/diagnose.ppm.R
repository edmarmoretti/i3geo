### Name: diagnose.ppm
### Title: Diagnostic Plots for Fitted Point Process Model
### Aliases: diagnose.ppm plot.diagppm
### Keywords: spatial models hplot

### ** Examples

    data(cells)
    fit <- ppm(cells, ~x, Strauss(r=0.15), rbord=0.15)
    diagnose.ppm(fit, rbord=0.15)
    diagnose.ppm(fit, type="pearson", rbord=0.15)
    diagnose.ppm(fit, rbord=0.15, which="marks")
    diagnose.ppm(fit, rbord=0.15, type="raw", plot.neg="discrete")

    # save the diagnostics and plot them later
    u <- diagnose.ppm(fit, rbord=0.15, plot.it=FALSE)
    plot(u)
    plot(u, which="marks") 



