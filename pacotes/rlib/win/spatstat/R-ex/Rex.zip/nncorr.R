### Name: nncorr
### Title: Nearest-Neighbour Correlation of Marked Point Pattern
### Aliases: nncorr
### Keywords: spatial nonparametric

### ** Examples

  data(finpines)
  nncorr(finpines)
  # heights of neighbouring trees are slightly negatively correlated

  data(amacrine)
  nncorr(amacrine, function(m1, m2) { m1 == m2})
  # neighbouring cells are usually of different type



