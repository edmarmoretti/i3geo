### Name: rMaternI
### Title: Simulate Matern Model I
### Aliases: rMaternI
### Keywords: spatial datagen

### ** Examples

 pp <- rMaternI(20, 0.05)



