### Name: plot.ppp
### Title: plot a Spatial Point Pattern
### Aliases: plot.ppp
### Keywords: spatial hplot

### ** Examples

   data(cells)
   plot(cells)

   plot(cells, pch=16)

   # make the plotting symbols larger (for publication at reduced scale)
   plot(cells, cex=2)

   # set it in spatstat.options
   oldopt <- spatstat.options(par.points=list(cex=2))
   plot(cells)
   spatstat.options(oldopt)

   # multitype 
   data(lansing)
   plot(lansing)

   # marked by a real number
   data(longleaf)
   plot(longleaf)

   # just plot the points
   plot(longleaf, use.marks=FALSE)
   plot(unmark(longleaf)) # equivalent

   # controlling COLOURS of points
   plot(cells, cols="blue")
   plot(lansing, cols=c("black", "yellow", "green", 
                        "blue","red","pink"))
   plot(longleaf, fg="blue")

   # make points and window purple
   plot(lansing, col="purple")
   # make everything purple
   plot(lansing, col="purple", col.main="purple")
 
   # controlling PLOT CHARACTERS
   plot(lansing, chars = 11:16)
   plot(lansing, chars = c("o","h","m",".","o","o"))

   # controlling MARK SCALE
   plot(longleaf, markscale=0.1)

   # draw circles of diameter equal to nearest neighbour distance
   plot(cells %mark% (nndist(cells)/2), markscale=1)

   # making the legend
   data(amacrine)
   v <- plot(amacrine)
   legend(0.2, 1.2, pch=v, legend=names(v))



