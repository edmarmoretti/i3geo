### Name: erode.owin
### Title: Erode a Window
### Aliases: erode.owin
### Keywords: spatial math

### ** Examples

  w <- owin(c(0,1),c(0,1))
  v <- erode.owin(w, 0.1) 
  # returns rectangle [0.1, 0.9] x [0.1,0.9]
  ## Not run: 
##D   v <- erode.owin(w, 0.6)
##D   #fails - erosion is empty
##D   
## End(Not run)



