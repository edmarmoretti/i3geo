### Name: Gcross
### Title: Multitype Nearest Neighbour Distance Function (i-to-j)
### Aliases: Gcross
### Keywords: spatial nonparametric

### ** Examples

    data(betacells)
     # cat retina data
    G01 <- Gcross(betacells, "off", "on") 
    plot(G01)

    # empty space function of `on' points
    ## Not run: 
##D        F1 <- Fest(betacells[betacells == "on"], r = G01$r, eps=10.0)
##D        lines(F1$r, F1$km, lty=3)
##D     
## End(Not run)

    # synthetic example    
    pp <- runifpoispp(50)
    pp <- pp %mark% factor(sample(0:1, pp$n, replace=TRUE))
    G <- Gcross(pp, "0", "1")   # note: "0" not 0



