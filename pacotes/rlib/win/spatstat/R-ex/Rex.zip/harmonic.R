### Name: harmonic
### Title: Basis for Harmonic Functions
### Aliases: harmonic
### Keywords: spatial models

### ** Examples

   data(longleaf)
   X <- unmark(longleaf)
   # inhomogeneous point pattern
   ## Don't show:
        # smaller dataset
        longleaf <- longleaf[seq(1,longleaf$n, by=50)]
   
## End Don't show

   # fit Poisson point process with log-cubic intensity
   fit.3 <- ppm(X, ~ polynom(x,y,3), Poisson())

   # fit Poisson process with log-cubic-harmonic intensity
   fit.h <- ppm(X, ~ harmonic(x,y,3), Poisson())

   # Likelihood ratio test
   lrts <- 2 * (fit.3$maxlogpl - fit.h$maxlogpl)
   x <- X$x
   y <- X$y
   df <- ncol(polynom(x,y,3)) - ncol(harmonic(x,y,3))
   pval <- 1 - pchisq(lrts, df=df)



