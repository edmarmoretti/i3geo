### Name: print.ppm
### Title: Print a Fitted Point Process Model
### Aliases: print.ppm
### Keywords: spatial print models

### ** Examples

 ## Not run: 
##D  data(cells)
##D  Q <- quadscheme(cells)
##D  m <- ppm(Q, ~1, Strauss(0.05))
##D  m
##D  
## End(Not run)



