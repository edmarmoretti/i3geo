### Name: is.multitype.ppp
### Title: Test Whether A Point Pattern is Multitype
### Aliases: is.multitype.ppp
### Keywords: spatial manip

### ** Examples

   data(cells)
   is.multitype(cells)  #FALSE - no marks
   data(longleaf)
   is.multitype(longleaf) #FALSE - real valued marks
   data(amacrine)
   is.multitype(amacrine) #TRUE



