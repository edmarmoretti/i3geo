### Name: rthin
### Title: Random Thinning
### Aliases: rthin
### Keywords: spatial datagen

### ** Examples

  data(redwood)
  plot(redwood, main="thinning")
  
  # delete 20% of points
  Y <- rthin(redwood, 0.8)
  points(Y, col="green", cex=1.4)

  # function
  f <- function(x,y) { ifelse(x < 0.4, 1, 0.5) }
  Y <- rthin(redwood, f)

  # pixel image
  Z <- as.im(f, redwood$window)
  Y <- rthin(redwood, Z)



