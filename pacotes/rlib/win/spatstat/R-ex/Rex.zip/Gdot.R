### Name: Gdot
### Title: Multitype Nearest Neighbour Distance Function (i-to-any)
### Aliases: Gdot
### Keywords: spatial nonparametric

### ** Examples

    data(betacells)
     # cat retina data
    G0. <- Gdot(betacells, "off") 
    plot(G0.)

    # synthetic example    
    pp <- runifpoispp(50)
    pp <- pp %mark% factor(sample(0:1, pp$n, replace=TRUE))
    G <- Gdot(pp, "0") # note: "0" not 0



