### Name: pppdist
### Title: Optimal Match Between Two Point Patterns
### Aliases: pppdist
### Keywords: spatial math

### ** Examples

   X <- runifpoint(42)
   Y <- runifpoint(42)
   pppdist(X, Y)
   pppdist(X[1:10], Y[1:10], q=Inf)



