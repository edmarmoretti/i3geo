### Name: MultiStraussHard
### Title: The Multitype/Hard Core Strauss Point Process Model
### Aliases: MultiStraussHard
### Keywords: spatial models

### ** Examples

   r <- matrix(3, nrow=2,ncol=2)
   h <- matrix(c(1,2,2,1), nrow=2,ncol=2)
   MultiStraussHard(1:2, r, h)
   # prints a sensible description of itself
   data(betacells)
   r <- 30.0 * matrix(c(1,2,2,1), nrow=2,ncol=2)
   h <- 30.0 * matrix(c(NA,1,1,NA), nrow=2,ncol=2)
   ppm(betacells, ~1, MultiStraussHard(c("off","on"), r, h), rbord=60.0)
   # fit the stationary multitype hardcore Strauss process to `betacells'



