### Name: rMaternII
### Title: Simulate Matern Model II
### Aliases: rMaternII
### Keywords: spatial datagen

### ** Examples

 pp <- rMaternII(20, 0.05)



