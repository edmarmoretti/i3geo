### Name: as.ppp
### Title: Convert Data To Class ppp
### Aliases: as.ppp as.ppp.ppp as.ppp.quad as.ppp.matrix as.ppp.default
### Keywords: spatial manip

### ** Examples

 ## Not run: 
##D  plot(c(0,1),c(0,1),type="n")
##D  xy <- locator(20) # click on 20 points in plot window
##D  pp <- as.ppp(xy, c(0,1,0,1))
##D  
##D  w <- owin(c(0,1),c(0,1))
##D  plot(w)                      # neater
##D  xy <- locator(20)            # click on 20 points in plot window
##D  pp <- as.ppp(xy, w)
##D  
## End(Not run) 
 
 xy <- matrix(runif(40), ncol=2)
 pp <- as.ppp(xy, c(0,1,0,1))
 
 # Venables-Ripley format
 require(spatial)
 towns <- ppinit("towns.dat")
 pp <- as.ppp(towns)   # converted to our format
 detach(package:spatial)



