### Name: envelope
### Title: Simulation envelopes of summary function
### Aliases: envelope
### Keywords: spatial htest hplot iteration

### ** Examples

 data(simdat)
 X <- simdat

 # Envelope of K function under CSR
 ## Not run: 
##D  plot(envelope(X))
##D  
## End(Not run)
 ## Don't show:
  plot(envelope(X, nsim=4))
 
## End Don't show

 # Translation edge correction (this is also FASTER):
 ## Not run: 
##D  plot(envelope(X, correction="translate"))
##D  
## End(Not run)
 ## Don't show:
  plot(envelope(X, nsim=4, correction="translate"))
 
## End Don't show

 # Envelope of K function for simulations from model 
 data(cells)
 fit <- ppm(cells, ~1, Strauss(0.05))
 ## Not run: 
##D  plot(envelope(fit))
##D  
## End(Not run)
 ## Don't show:
  plot(envelope(fit, nsim=4))
 
## End Don't show

 # Envelope of G function under CSR
 ## Not run: 
##D  plot(envelope(X, Gest))
##D  
## End(Not run)
 ## Don't show:
  plot(envelope(X, Gest, nsim=4))
 
## End Don't show

 # Envelope of L function under CSR
 #  L(r) = sqrt(K(r)/pi)
 ## Not run: 
##D   E <- envelope(X, Kest)
##D   plot(E, sqrt(./pi) ~ r)
##D  
## End(Not run)
 ## Don't show:
  E <- envelope(X, Kest, nsim=4)
  plot(E, sqrt(./pi) ~ r)
 
## End Don't show

 # Simultaneous critical envelope for L function
 ## Not run: 
##D   plot(envelope(X, Kest, transform=expression(sqrt(./pi)), global=TRUE))
##D  
## End(Not run)
 ## Don't show:
 plot(envelope(X, Kest, nsim=4,transform=expression(sqrt(./pi)), global=TRUE))
 
## End Don't show

 # How to pass arguments needed to compute the summary functions:
 # We want envelopes for Jcross(X, "A", "B") 
 # where "A" and "B" are types of points in the dataset 'demopat'

 data(demopat)
 ## Not run: 
##D  plot(envelope(demopat, Jcross, i="A", j="B"))
##D  
## End(Not run)
 ## Don't show:
 plot(envelope(demopat, Jcross, i="A", j="B", nsim=4))
 
## End Don't show
 
 # Use of `simulate'
 ## Not run: 
##D  plot(envelope(cells, Gest, simulate=expression(runifpoint(42))))
##D  plot(envelope(cells, Gest, simulate=expression(rMaternI(100,0.02))))
##D  
## End(Not run)
 ## Don't show:
  plot(envelope(cells, Gest, simulate=expression(runifpoint(42)), nsim=4))
  plot(envelope(cells, Gest, simulate=expression(rMaternI(100, 0.02)), nsim=4))
 
## End Don't show

 # Envelope under random toroidal shifts
 data(amacrine)
 ## Not run: 
##D  plot(envelope(amacrine, Kcross, i="on", j="off",
##D                simulate=expression(rshift(amacrine, radius=0.25)))) 
##D  
## End(Not run)

 # Envelope under random shifts with erosion
 ## Not run: 
##D  plot(envelope(amacrine, Kcross, i="on", j="off",
##D               simulate=expression(rshift(amacrine, radius=0.1, edge="erode"))))
##D  
## End(Not run)
  
 # Envelope of INHOMOGENEOUS K-function with fitted trend
## Not run: 
##D  trend <- density.ppp(X, 1.5)
##D  plot(envelope(X, Kinhom, lambda=trend,
##D          simulate=expression(rpoispp(trend))))
##D  
## End(Not run)
  



