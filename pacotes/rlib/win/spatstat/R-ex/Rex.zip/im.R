### Name: im
### Title: Create a Pixel Image Object
### Aliases: im
### Keywords: spatial manip datagen

### ** Examples

   vec <- rnorm(1200)
   mat <- matrix(vec, nrow=30, ncol=40)
   whitenoise <- im(mat)
   whitenoise <- im(mat, xcol=seq(0,1,length=40), yrow=seq(0,1,length=30))
   whitenoise <- im(vec, xcol=seq(0,1,length=40), yrow=seq(0,1,length=30))
   plot(whitenoise)

   # FACTOR-VALUED IMAGES:
   cutvec <- cut(mat, 3)
   # although mat was a matrix, cutvec is a vector, with factor values
   cutwhite <- im(cutvec, xcol=seq(0,1,length=40), yrow=seq(0,1,length=30))
   # cutwhite is a factor-valued image
   plot(cutwhite)



