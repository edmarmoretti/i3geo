### Name: ripras
### Title: Estimate window from points alone
### Aliases: ripras
### Keywords: spatial utilities

### ** Examples

  ## Not run: 
##D   plot(owin())
##D   
## End(Not run)
  x <- runif(30)
  y <- runif(30)
  ## Not run: points(x,y)
  w <- ripras(x,y)
  ## Not run: 
##D   plot(w, box=FALSE)
##D   points(x,y)
##D   
## End(Not run)



