### Name: Poisson
### Title: Poisson Point Process Model
### Aliases: Poisson
### Keywords: spatial models

### ** Examples

 data(nztrees)
 ppm(nztrees, ~1, Poisson())
 # fit the stationary Poisson process to 'nztrees'
 # no edge correction needed

 data(longleaf)
 ## Don't show:
   longleaf <- longleaf[seq(1, longleaf$n, by=50)]
 
## End Don't show
 longadult <- longleaf[longleaf$marks >= 30, ]
 longadult <- unmark(longadult)
 ppm(longadult, ~ x, Poisson())
 # fit the nonstationary Poisson process 
 # with intensity lambda(x,y) = exp( a + bx)

 data(lansing)
 # trees marked by species
 ## Don't show:
     lansing <- lansing[seq(1,lansing$n, by=30), ]
 
## End Don't show
 ppm(lansing, ~ marks, Poisson())
 # fit stationary marked Poisson process
 # with different intensity for each species

## Not run: 
##D  ppm(lansing, ~ marks * polynom(x,y,3), Poisson())
## End(Not run)
 # fit nonstationary marked Poisson process
 # with different log-cubic trend for each species
## Don't show:
 # equivalent functionality - smaller dataset
 data(betacells)
 ppm(betacells, ~ marks * polynom(x,y,2), Poisson())
## End Don't show



