### Name: nndist
### Title: Nearest neighbour distances
### Aliases: nndist nndist.ppp nndist.default
### Keywords: spatial math

### ** Examples

   data(cells)
   d <- nndist(cells)

   x <- runif(100)
   y <- runif(100)
   d <- nndist(x, y)

   # Stienen diagram
   plot(cells %mark% (nndist(cells)/2), markscale=1)



