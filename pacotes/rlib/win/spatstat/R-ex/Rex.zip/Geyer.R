### Name: Geyer
### Title: Geyer's Saturation Point Process Model
### Aliases: Geyer
### Keywords: spatial models

### ** Examples

   data(cells) 
   ppm(cells, ~1, Geyer(r=0.07, sat=2), rbord=0.07)
   # fit the stationary saturation process to `cells'



