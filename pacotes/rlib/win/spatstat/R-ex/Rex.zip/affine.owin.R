### Name: affine.owin
### Title: Apply Affine Transformation To Window
### Aliases: affine.owin
### Keywords: spatial math

### ** Examples

  # shear transformation
  X <- affine(owin(), matrix(c(1,0,0.6,1),ncol=2))
  ## Not run: 
##D   plot(X)
##D   
## End(Not run)



