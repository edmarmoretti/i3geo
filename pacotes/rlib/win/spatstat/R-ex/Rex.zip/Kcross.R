### Name: Kcross
### Title: Multitype K Function (Cross-type)
### Aliases: Kcross
### Keywords: spatial nonparametric

### ** Examples

    data(betacells)
     # cat retina data
    K01 <- Kcross(betacells, "off", "on") 
    plot(K01)

    K10 <- Kcross(betacells, "on", "off")

    # synthetic example    
    pp <- runifpoispp(50)
    pp <- pp %mark% factor(sample(0:1, pp$n, replace=TRUE))
    K <- Kcross(pp, "0", "1") # note: "0" not 0



