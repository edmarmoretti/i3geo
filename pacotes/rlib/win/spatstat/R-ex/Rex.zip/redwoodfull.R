### Name: redwoodfull
### Title: California Redwoods Point Pattern (Entire Dataset)
### Aliases: redwoodfull redwoodfull.extra
### Keywords: datasets spatial

### ** Examples

       data(redwoodfull)
       plot(redwoodfull)
       redwoodfull.extra$plot()
       # extract the pattern in region II 
       redwoodII <- redwoodfull[, redwoodfull.extra$regionII]



