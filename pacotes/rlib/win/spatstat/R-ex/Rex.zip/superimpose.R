### Name: superimpose
### Title: Superimpose Several Point Patterns
### Aliases: superimpose
### Keywords: spatial manip

### ** Examples

  dat <- runifrect(30)
  xy <- list(x=runif(10),y=runif(10))
  new <- superimpose(dat, xy)
  ## Not run: plot(new)

  # how to make a 2-type point pattern with types "a" and "b"
  u <- superimpose(a = rpoispp(10), b = rpoispp(20))

  # how to make a 2-type point pattern with types 1 and 2
  u <- superimpose("1" = rpoispp(10), "2" = rpoispp(20))



