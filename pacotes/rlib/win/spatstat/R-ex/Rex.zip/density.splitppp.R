### Name: density.splitppp
### Title: Kernel Smoothed Intensity of Split Point Pattern
### Aliases: density.splitppp
### Keywords: spatial methods smooth

### ** Examples

  data(amacrine)
  Z <- density(split(amacrine), 0.05)
  plot(Z)



