### Name: plot.psp
### Title: plot a Spatial Line Segment Pattern
### Aliases: plot.psp
### Keywords: spatial hplot

### ** Examples

   a <- psp(runif(20), runif(20), runif(20), runif(20), window=owin())
   plot(a)
   plot(a, main="My title")
   plot(a, col="blue")
   plot(a, lwd=3)



