### Name: StraussHard
### Title: The Strauss / Hard Core Point Process Model
### Aliases: StraussHard
### Keywords: spatial models

### ** Examples

   StraussHard(r=1,hc=0.02)
   # prints a sensible description of itself

   data(cells) 
   ppm(cells, ~1, StraussHard(r=0.1, hc=0.05), rbord=0.1)
   # fit the stationary Strauss/hard core  process to `cells'

   ppm(cells, ~ polynom(x,y,3), StraussHard(r=0.1, hc=0.05), rbord=0.1)
   # fit a nonstationary Strauss/hard core process
   # with log-cubic polynomial trend
   


