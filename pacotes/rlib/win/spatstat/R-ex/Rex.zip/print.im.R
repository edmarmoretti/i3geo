### Name: print.im
### Title: Print Brief Details of an Image
### Aliases: print.im
### Keywords: spatial print

### ** Examples

  data(letterR)
  U <- as.im(letterR)
  U



