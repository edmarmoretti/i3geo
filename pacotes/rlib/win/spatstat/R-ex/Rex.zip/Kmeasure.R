### Name: Kmeasure
### Title: Reduced Second Moment Measure
### Aliases: Kmeasure
### Keywords: spatial nonparametric

### ** Examples

 data(cells)
 image(Kmeasure(cells, 0.05))
 # shows pronounced dip around origin consistent with strong inhibition
 data(redwood)
 image(Kmeasure(redwood, 0.03), col=grey(seq(1,0,length=32)))
 # shows peaks at several places, reflecting clustering and ?periodicity



