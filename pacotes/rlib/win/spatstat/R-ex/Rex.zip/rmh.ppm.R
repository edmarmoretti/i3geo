### Name: rmh.ppm
### Title: Simulate from a Fitted Point Process Model
### Aliases: rmh.ppm
### Keywords: spatial models datagen

### ** Examples

   data(swedishpines)
   X <- swedishpines
   plot(X, main="Swedish Pines data")

   # Poisson process
   fit <- ppm(X, ~1, Poisson())
   Xsim <- rmh(fit)
   plot(Xsim, main="simulation from fitted Poisson model")

   # Strauss process   
   fit <- ppm(X, ~1, Strauss(r=7), rbord=7)
   Xsim <- rmh(fit, control=list(nrep=1e3))
   plot(Xsim, main="simulation from fitted Strauss model")

   ## Not run: 
##D    # Strauss process simulated on a larger window
##D    # then clipped to original window
##D    Xsim <- rmh(fit, control=list(nrep=1e3, expand=2, periodic=TRUE))
##D    
##D    # Strauss - hard core process
##D    fit <- ppm(X, ~1, StraussHard(r=7,hc=2), rbord=7)
##D    Xsim <- rmh(fit, start=list(n.start=X$n), control=list(nrep=1e3))
##D    plot(Xsim, main="simulation from fitted Strauss hard core model")
##D 
##D    # Geyer saturation process
##D    fit <- ppm(X, ~1, Geyer(r=7,sat=2), rbord=7)
##D    Xsim <- rmh(fit, start=list(n.start=X$n), control=list(nrep=1e3))
##D    plot(Xsim, main="simulation from fitted Geyer model")
##D 
##D    # soft core interaction process
##D    Q <- quadscheme(X, nd=50)
##D    fit <- ppm(Q, ~1, Softcore(kappa=0.1))
##D    Xsim <- rmh(fit, start=list(n.start=X$n), control=list(nrep=1e3))
##D    plot(Xsim, main="simulation from fitted Soft Core model")
##D 
##D    data(cells)
##D    plot(cells)
##D    # Diggle-Gratton pairwise interaction model
##D    fit <- ppm(cells, ~1, DiggleGratton(0.05, 0.1))
##D    Xsim <- rmh(fit, start=list(n.start=cells$n), control=list(nrep=1e3))
##D    plot(Xsim, main="simulation from fitted Diggle-Gratton model")
##D 
##D    X <- rSSI(0.05, 100)
##D    plot(X, main="new data")
##D 
##D    # piecewise-constant pairwise interaction function
##D    fit <- ppm(X, ~1, PairPiece(seq(0.02, 0.1, by=0.01)))
##D    Xsim <- rmh(fit, control=list(nrep=1e3))
##D    plot(Xsim, main="simulation from fitted pairwise model")
##D 
##D    # marked point pattern
##D    data(amacrine)
##D    Y <- amacrine
##D    plot(Y, main="Amacrine data")
##D 
##D    # marked Poisson models 
##D    fit <- ppm(Y)
##D    Ysim <- rmh(fit)
##D    plot(Ysim, main="simulation from ppm(Y)")
##D 
##D    fit <- ppm(Y,~marks)
##D    Ysim <- rmh(fit)
##D    plot(Ysim, main="simulation from ppm(Y, ~marks)")
##D 
##D    fit <- ppm(Y,~polynom(x,y,2))
##D    Ysim <- rmh(fit)
##D    plot(Ysim, main="simulation from ppm(Y, ~polynom(x,y,2))")
##D 
##D    fit <- ppm(Y,~marks+polynom(x,y,2))
##D    Ysim <- rmh(fit)
##D    plot(Ysim, main="simulation from ppm(Y, ~marks+polynom(x,y,2))")
##D 
##D    fit <- ppm(Y,~marks*polynom(x,y,2))
##D    Ysim <- rmh(fit)
##D    plot(Ysim, main="simulation from ppm(Y, ~marks*polynom(x,y,2))")
##D 
##D    # multitype Strauss models
##D    MS <- MultiStrauss(types = levels(Y$marks),
##D                       radii=matrix(0.07, ncol=2, nrow=2))
##D    fit <- ppm(Y, ~marks, MS)
##D    Ysim <- rmh(fit, control=list(nrep=1e3))
##D    plot(Ysim, main="simulation from fitted Multitype Strauss")
##D 
##D    fit <- ppm(Y,~marks*polynom(x,y,2), MS)
##D    Ysim <- rmh(fit, control=list(nrep=1e3))
##D    plot(Ysim, main="simulation from fitted inhomogeneous Multitype Strauss")
##D    
## End(Not run)



