### Name: plot.fasp
### Title: Plot a Function Array
### Aliases: plot.fasp
### Keywords: spatial hplot

### ** Examples

   ## Not run: 
##D    # Bramble Canes data.
##D    data(bramblecanes)
##D 
##D    X.G <- alltypes(bramblecanes,type="G",dataname="Bramblecanes",verb=TRUE)
##D    plot(X.G)
##D    plot(X.G,subset="r<=0.2")
##D    plot(X.G,formule=cbind(asin(sqrt(km)),
##D                     asin(sqrt(theo))) ~ asin(sqrt(theo)))
##D        plot(X.G,fo=cbind(km-theo,0)~r,"r<=0.2")
##D 
##D    # Swedish pines.
##D    data(swedishpines)
##D    X <- allstats(swedishpines,dataname="Swedish Pines")
##D    plot(X,subset=list("r<=20","r<=20","r<=20","r<=50"))
##D 
##D    # Simulated data.
##D    pp <- runifpoint(350, owin(c(0,1),c(0,1)))
##D    pp$marks <- factor(c(rep(1,50),rep(2,100),rep(3,200)))
##D    X.K <- alltypes(pp,type="K",verb=TRUE,dataname="Fake Data")
##D    plot(X.K,fo=cbind(border,theo)~theo,"theo<=0.75")
##D    
## End(Not run)



