### Name: diameter
### Title: Diameter of a Window Frame
### Aliases: diameter
### Keywords: spatial math

### ** Examples

  w <- owin(c(0,1),c(0,1))
  diameter(w) 
  # returns sqrt(2)



