### Name: anova.ppm
### Title: ANOVA for Fitted Point Process Models
### Aliases: anova.ppm
### Keywords: spatial models methods

### ** Examples

 data(swedishpines)
 mod0 <- ppm(swedishpines, ~1, Poisson())
 modx <- ppm(swedishpines, ~x, Poisson())
 anova.ppm(modx, mod0, test="Chi")



