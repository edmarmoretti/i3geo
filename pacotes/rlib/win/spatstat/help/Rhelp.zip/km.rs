km.rs                package:spatstat                R Documentation

_K_a_p_l_a_n-_M_e_i_e_r _a_n_d _R_e_d_u_c_e_d _S_a_m_p_l_e _E_s_t_i_m_a_t_o_r _u_s_i_n_g _H_i_s_t_o_g_r_a_m_s

_D_e_s_c_r_i_p_t_i_o_n:

     Compute the Kaplan-Meier and Reduced Sample estimators of a
     survival time distribution function, using histogram techniques

_U_s_a_g_e:

       km.rs(o, cc, d, breaks)

_A_r_g_u_m_e_n_t_s:

       o: vector of observed survival times 

      cc: vector of censoring times 

       d: vector of non-censoring indicators 

  breaks: Vector of breakpoints to be used to form histograms. 

_D_e_t_a_i_l_s:

     This function is needed mainly for internal use in 'spatstat', but
     may be useful in other applications where you want to form the
     Kaplan-Meier estimator from a huge dataset.

     Suppose T[i] are the survival times of individuals i=1,...,M with
     unknown distribution function F(t) which we wish to estimate.
     Suppose these times are right-censored by random censoring times
     C[i]. Thus the observations consist of right-censored survival
     times T*[i] = min(T[i],C[i]) and non-censoring indicators D[i] =
     1(T[i] <= C[i]) for each i.

     The arguments to this function are  vectors 'o', 'cc', 'd' of
     observed values of T*[i], C[i] and D[i] respectively. The function
     computes histograms and forms the reduced-sample and Kaplan-Meier
     estimates of  F(t) by invoking the functions 'kaplan.meier' and
     'reduced.sample'. This is efficient if the lengths of 'o', 'cc',
     'd' (i.e. the number of observations) is large.

     The vectors 'km' and 'hazard' returned by 'kaplan.meier' are
     (histogram approximations to) the Kaplan-Meier estimator of F(t)
     and its hazard rate lambda(t). Specifically, 'km[k]' is an
     estimate of 'F(breaks[k+1])', and 'lambda[k]' is an estimate of
     the average of lambda(t) over the interval
     '(breaks[k],breaks[k+1])'. This approximation is exact only if the
     survival times are discrete and the  histogram breaks are fine
     enough to ensure that each interval '(breaks[k],breaks[k+1])'
     contains only one possible value of the survival time. 

     The vector 'rs' is the reduced-sample estimator, 'rs[k]' being the
     reduced sample estimate of 'F(breaks[k+1])'. This value is exact,
     i.e. the use of histograms does not introduce any approximation
     error in the reduced-sample estimator.

_V_a_l_u_e:

     A list with five elements 

      rs: Reduced-sample estimate of the survival time c.d.f. F(t) 

      km: Kaplan-Meier estimate of the survival time c.d.f. F(t) 

  hazard: corresponding Nelson-Aalen estimate of the hazard rate
          lambda(t) 

       r: values of t for which F(t) is estimated 

  breaks: the breakpoints vector 

_A_u_t_h_o_r(_s):

     Adrian Baddeley adrian@maths.uwa.edu.au <URL:
     http://www.maths.uwa.edu.au/~adrian/> and Rolf Turner
     rolf@math.unb.ca <URL: http://www.math.unb.ca/~rolf>

_S_e_e _A_l_s_o:

     'reduced.sample', 'kaplan.meier'

