### Name: sinkplot
### Title: Send textual R output to a graphics device
### Aliases: sinkplot
### Keywords: hplot

### ** Examples

## Not run: 
##D    set.seed(12456)
##D    x <- factor(sample( LETTERS[1:5], 50, replace=TRUE))
##D    y <- rnorm(50, mean=as.numeric(x), sd=1)
##D 
##D    par(mfrow=c(1,2))
##D    boxplot(y~x, col="darkgreen")
##D 
##D    sinkplot()
##D    anova(lm(y~x))
##D    sinkplot("plot",col="darkgreen")
## End(Not run)



