### Name: resample
### Title: Consistent Random Samples and Permutations
### Aliases: resample
### Keywords: misc

### ** Examples

##---- Should be DIRECTLY executable !! ----
##-- ==>  Define data, use random,
##--    or do  help(data=index)  for the standard data sets.

## The function is currently defined as
function(x, n, ...)
  {
    if(length(x)==1)
      {
        if(n==1)
          x
        else
          stop("Requested sample of size ", n, " from list of length 1")
      }
    else
      sample(x, n, ...)
  }



