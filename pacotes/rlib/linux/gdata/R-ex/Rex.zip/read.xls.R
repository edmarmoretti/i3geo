### Name: read.xls
### Title: Read Excel files
### Aliases: read.xls
### Keywords: file

### ** Examples


   # iris.xls is included in the gregmisc package for use as an example
   xlsfile <- file.path(.path.package('gdata'),'xls','iris.xls')
   xlsfile

   iris <- read.xls(xlsfile)
   head(iris)  # look at the top few rows

  ## Not run: 
##D    # Example specifying exact Perl path for default MS-Windows install of
##D    # ActiveState perl
##D    iris <- read.xls(xlsfile, perl="C:\perl\bin\perl.exe")
##D 
##D    # Example specifying exact Perl path for Unix systems
##D    iris <- read.xls(xlsfile, perl="/usr/bin/perl")
##D    
## End(Not run)



