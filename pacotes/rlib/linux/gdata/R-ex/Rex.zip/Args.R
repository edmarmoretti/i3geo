### Name: Args
### Title: Formatted Argument List of a Function
### Aliases: Args
### Keywords: programming utilities documentation

### ** Examples

Args(glm)
Args(scan)
Args(legend)



