### Name: c.factor
### Title: Combine factors, properly handling levels
### Aliases: c.factor
### Keywords: manip

### ** Examples

f1 <- factor(letters[1:10])
f2 <- factor(letters[5:14])

c(f1,f2)




