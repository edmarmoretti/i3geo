### Name: grid.grob
### Title: Create a Grid Graphical Object
### Aliases: grid.grob grob gTree childNames gList
### Keywords: dplot

### ** Examples




