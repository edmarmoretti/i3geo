### Name: grid.plot.and.legend
### Title: A Simple Plot and Legend Demo
### Aliases: grid.plot.and.legend
### Keywords: dplot

### ** Examples

grid.plot.and.legend()



