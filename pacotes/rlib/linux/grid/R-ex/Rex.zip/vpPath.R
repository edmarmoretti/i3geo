### Name: vpPath
### Title: Concatenate Viewport Names
### Aliases: vpPath
### Keywords: dplot

### ** Examples

vpPath("vp1", "vp2")



