### Name: getNames
### Title: List the names of grobs on the display list
### Aliases: getNames
### Keywords: dplot

### ** Examples

grid.grill()
getNames()



